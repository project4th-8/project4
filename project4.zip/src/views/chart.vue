<template>
  <div id="radar" class="container"></div>
</template>
<script>
import  echarts from 'echarts/lib/echarts'
import  'echarts/lib/component/tooltip'
import  'echarts/lib/component/legend'

export default {
  name:"test",
  mounted() {
      const option = {  //创建图表配置数据
    title: {
        text: ''
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data:['收益走势']
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['周一','周二','周三','周四','周五','周六','周日']
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name:'收益走势',
            type:'line',
            stack: '总量',
            data:[0.32, 0.23, 0.2, 0.1, 0.12, 0.34, 0.24]
        }
    ]
      }
     //初始化图表
      const chartObj = echarts.init(document.getElementById('radar'))
      chartObj.setOption(option)
    }
  
}
</script>
<style lang="less" scoped>
  .container{
    width: 320px;
    height: 240px;
  }
</style>