<template>
  <div>
   <van-icon name="close" />

    <top>
      
    </top>
  </div>
</template>
<script>
import top from "../components/top";


export default {
  name: "index"
  
  
}

</script>