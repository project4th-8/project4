<template>
  <div class="fix-top">

 <Recommendtext v-for="(item,index) in cons" :key='index' :info='item'></Recommendtext>
  </div>
</template>
<script>
import Recommendtext from '../components/recommendtext'

export default {
  name:'recommend',
  data () {
    return {
      cons:[]
    }
  },
  components: {
    Recommendtext
  },
  computed:{

  },
  created(){

     this.axios.get("/dynamic/findAllDUR", {
       
      })
      .then(res => {
        this.cons = res.data.data.data
     
      }) 
  
  },
  methods:{
 
  }
}
</script>
<style lang="less" scoped>
.fix-top {
  margin-top:90px; 
  margin-bottom:40px; 
}
</style>