<template>
  <div>
    fund-6
  </div>
</template>
<script>
export default {
  name:'fundsix'
}
</script>