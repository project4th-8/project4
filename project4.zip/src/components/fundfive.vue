<template>
  <div>
    fund-5
  </div>
</template>
<script>
export default {
  name:'fundfive'
}
</script>