<template>
  <div>
    fund-1
  </div>
</template>
<script>
export default {
  name:'fundone'
}
</script>