<template>
  <div>
    fund-4
  </div>
</template>
<script>
export default {
  name:'fundfour'
}
</script>