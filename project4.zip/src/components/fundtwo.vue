<template>
  <div>
    fund-2
  </div>
</template>
<script>
export default {
  name:'fundtwo'
}
</script>