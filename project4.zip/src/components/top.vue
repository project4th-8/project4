<template>
  <div class="top">
    <div class="top-list">
    <input type="text">
    xxx
    </div>

  </div>
</template>

<script>
export default {
  name:'top'
}
</script>
<style lang="less" scoped>
 .top {
   height: 64px;
   background: #5f5e5e;
   font-size: 24px;
 }
  .top-list {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
 
  }

</style>